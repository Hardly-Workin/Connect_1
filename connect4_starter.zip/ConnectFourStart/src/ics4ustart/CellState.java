package ics4ustart;

public enum CellState {
	EMPTY, P1, P2
}
